import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;


public class Main {
	
	 public static void main(String[] args) {
		 
		 HashMap<String, String> hmap = new HashMap<>();
		 String filepath = "segment1";
		 String filepath2 = "Conutfile";
		 try {
			BufferedWriter writer1 = new BufferedWriter(new FileWriter("matrixfinalfile"));
		
			File file = new File(filepath);
			File file1 = new File(filepath2);
			String line = null;
			BufferedReader br = new BufferedReader(new FileReader(file));
			BufferedReader br2 = new BufferedReader(new FileReader(file1));
			
			
			String seg ="174";
			try {
				while ((line= br2.readLine()) != null) {
					//System.out.println("line: " + line);
					if(line.contains(","))
					{
						String[] kv = line.split(",");
						hmap.put(kv[0], kv[1]);
					}
					else 
						hmap.put(line, "");
				}
				while ((line= br.readLine()) != null) {
					
					if(hmap.containsKey(line))
				    {
						for (String i : hmap.keySet()) {
							if(line.equals(i))
							{
								String temp = hmap.get(i)+" "+seg;
								hmap.put(i, temp);
							}
						  //System.out.println("key: " + i + " value: " + capitalCities.get(i));
							}
					}
					else
					{
						hmap.put(line,seg);
					}
					
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 
		 
		 
		 
		/* if(hmap.containsKey("a"))
			 valSetOne.add(2);
		 
		 Set<String> keys = hmap.keySet();	*/
		 
		 Set<Entry<String, String>> hashSet=hmap.entrySet();
	        for(Entry entry:hashSet ) {
                String print = entry.getKey()+","+entry.getValue();
	            //System.out.println("Key="+entry.getKey()+", Value="+entry.getValue());
	            writer1.write(print + "\n");
	        }
		 writer1.close();
		 
		 } 
		 catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 

	       
	    }

}
