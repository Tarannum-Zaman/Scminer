import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Main {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		long startTime = System.nanoTime();
		
		
		// TODO Auto-generated method stub
		String filepath = "/home/shaila/Documents/LocRoCon/bash/audit1/auditlog";
		File file = new File(filepath);
		int linenum[] = null, i=0;
		String line = null;
		ArrayList<String> linearr = new ArrayList<String>();
		Set<String> filterline = new HashSet<String>(1000000);
		Set<String> names = new HashSet<String>(10000);
		Set<String> sharednames = new HashSet<String>(10000);
		BufferedReader br = new BufferedReader(new FileReader(file));
		BufferedReader br1 = new BufferedReader(new FileReader(file));
		String [] arrofstr = null;
		String [] arrofstr1 = null;
		
		File fout = new File("/home/shaila/Documents/LocRoCon/bash/sharedresource");
		
		FileOutputStream fos = new FileOutputStream(fout);
		
		int count =0, lineno=0, countline =0, flag =0,namecount =0;
		
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		
		while ((line= br.readLine()) != null) {
			//System.out.println(line);
			linearr.add(line);
			//linearr[lineno] = line;
			lineno++;
			int intIndex = line.indexOf("/home/shaila/Documents/work_example/bash-3.0/history");
			int intIndexname = line.indexOf("name=");
			if(intIndexname != -1 && flag == 1)
			{   namecount = namecount+1;
				continue;
			}
			if(intIndex == - 1 || intIndexname == -1) {
		        // System.out.println("name not found;");
				if(flag == 1 && namecount!=0)
				{
				
					filterline.add(linearr.get(lineno-1));
				}
				
				
		      } else {
		    	  System.out.println("history found at line: " +lineno);
		    	  filterline.add(linearr.get(lineno-3));
		    	  //System.out.println(linearr.get(lineno-3));
		    	  filterline.add(linearr.get(lineno-2));
		    	  //System.out.println(linearr.get(lineno-2));
		    	  filterline.add(linearr.get(lineno-1));
		    	  //System.out.println(linearr.get(lineno-1));
		    	  //if(intIndexname == -1)
		    	  flag =1;
		    	  namecount =0;
		    	 //break;
		         
		      }
			
		}
		for(String a: filterline){
			bw.write(a);
			bw.newLine();
			System.out.println(a);
			
		}
		bw.close();
		//num of shared resource:
		System.out.println("Number of Found unique name: " +  names.size());
		int k=0;
		for(String a: names){
			int tempcount =0;
			k++;
			System.out.println(a);
			while ((line = br1.readLine()) != null) {
				int intIndex = line.indexOf(a);
				//System.out.println(intIndex);
				if(intIndex == - 1) {
					//System.out.println("not shared resource");
				}
				else{
					tempcount++;
					arrofstr1 = line.split(" ");
					//System.out.println(arrofstr1[0]);
					for(String b: arrofstr){
						if(b.contains("item=0"))
						{
							// do nothing
						}
						else
							sharednames.add(a);
					}
				}
			}
		}
			
			System.out.println(k);
			

		for(String a: sharednames){
			System.out.println(a);
			
		}
		long endTime   = System.nanoTime();
		long totalTime = endTime - startTime;
		System.out.println("time:" +totalTime/1000000);
	}


}
