import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


public class Main {
	
	public static void main(String[] args) throws IOException {
	int[][] matrix = new int [174][924];
	String filepath = "test";
	File file = new File(filepath);
	String line= null;
	BufferedReader br = new BufferedReader(new FileReader(file));
	BufferedWriter writer1 = new BufferedWriter(new FileWriter("testmatrix"));
	int lineno =0;
	
	while ((line= br.readLine()) != null) {
		lineno++;
		String[] column = line.split(",");
		writer1.write(column[0] + " ");
		String[] value = column[1].split(" ");
		//System.out.println("lineno1:" +lineno);
		
		//int index=0;
		for(int index =0; index< value.length;index++)
		{   int count =1;
			int temp = Integer.parseInt(value[index]);
			System.out.println("temp:" +temp);
			//System.out.println("lineno:" +lineno);
			
			for(int j = 1; j<= 174; j++){ ////////////put the number of rows here...means segments
					if(temp == j){
						matrix[j-1][lineno-1] = count;
						System.out.println("matrix:" + matrix[j-1][lineno-1]);
						for(int x=index; x < value.length-1 ;x++)
						{
							System.out.println("x" +x + "valuelength" + value.length);
							//if(x < value.length-1)
							//{   
								if (value[x].equals(value[x+1])){
									System.out.println("value[x]" +value[x] + "value[x+1]" + value[x+1]);
									count = count+1;
									matrix[j-1][lineno-1] = count;
									System.out.println("matrix:" + matrix[j-1][lineno-1]);
									index++;
								}
								else
									break;
							//}
							
							 
						}
						
		                  //System.out.println("j+temp:" +j + temp);
						 //}
						 
						 //else{
							 //count=1;
							 //break;
						 //}
							 
					   //System.out.println("j+temp:" +j + temp);
						//}
						//count =1;
				}
					//else
					//matrix[j][i] =0;
				
				//}
			}
			
		}
		
	}
		writer1.write("\n");
	for(int j = 0; j< 174; j++){ ///number of row
		for(int i=0; i<924; i++) /// number of column
		{
			//if(temp == lineno)
			//System.out.println(matrix[j][i]);
			writer1.write(matrix[j][i]+ " ");
			
		
		}
		writer1.write("\n");
	}
	writer1.close();
	
	
	}
	
}
