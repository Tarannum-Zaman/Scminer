import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Main {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		long startTime = System.nanoTime();
		
		
		// TODO Auto-generated method stub
		String filepath = "/home/shaila/Documents/LocRoCon/mv_cat/test_multipletestcases/auditbiglog6";
		BufferedWriter writer1 = new BufferedWriter(new FileWriter("/home/shaila/Documents/LocRoCon/mv_cat/test_multipletestcases/results/resourcelist6"));
		File file = new File(filepath);
		List linenum = new ArrayList<Integer>();
		//int linenum[] = null;
		String line = null;
		
		ArrayList<String> linearr = new ArrayList<String>();
		Set<String> filterline = new HashSet<String>(1000000);
		Set<String> names = new HashSet<String>(10000);
		Set<String> process = new HashSet<String>(10000);
		Set<String> sharednames = new HashSet<String>(10000);
		BufferedReader br = new BufferedReader(new FileReader(file));
		//BufferedReader br1 = new BufferedReader(new FileReader(file));
		String [] arrofstr = null;
		String [] arrofstr1 = null;
		
		//File fout = new File("/home/shaila/Documents/LocRoCon//bash/audit1/");
		
		//FileOutputStream fos = new FileOutputStream(fout);
		
		int count =0, lineno=0, countline =0, flag =0, namecount =0, k =0;
		int syscallcount =0;
		//BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		
		while ((line= br.readLine()) != null) {
			lineno++;
			int intIndex = line.indexOf("syscall=59");
			if(intIndex != -1)
			{   //System.out.println("lineno" + lineno);
			    linenum.add(lineno);
			    k++;
			}
			int intIndsys = line.indexOf("syscall=");
			if(intIndsys != -1)
			{   
				syscallcount++;
			}
			int intInd = line.indexOf("pid=");
			if(intInd != -1)
			{   
			    String[] temp = line.split(" ");
			    
			    for(String a: temp){
			    	if (a.contains("pid=") && a.charAt(1)=='i')
			    	{
			    		//String ptemp = a+ " " + Integer.toString(lineno);
			    		process.add(a);
			    		writer1.write(a+"\n");
			    	}
			    }
			}
			int intIndex0 = line.indexOf("name=");
			if(intIndex0 != -1)
			{   
			    String[] temp = line.split(" ");
			    
			    for(String a: temp){
			    	if (a.contains("name="))
			    	{   //String ntemp = a+ " " + Integer.toString(lineno);
			    		names.add(a);
			    		writer1.write(a+"\n");
			    	}
			    }
			}
			
			
			
		}writer1.close();
		
		//System.out.println("lineno......" + linenum.size());
		for(int i =0; i< linenum.size()-1;i++)
		{ 	
			int lineno1=0;
			String line1 = null;
			BufferedReader br1 = new BufferedReader(new FileReader(file));
			BufferedWriter writer = new BufferedWriter(new FileWriter("/home/shaila/Documents/LocRoCon/mv_cat/test_multipletestcases/results/exe"+i));
			//System.out.println("lineno......" + (int)linenum.get(i));
		//BufferedWriter writer = new BufferedWriter(new FileWriter("/home/shaila/Documents/LocRoCon//bash/audit1/exe1"));
			while ((line1 = br1.readLine())!= null) {
				lineno1++;
				//System.out.println("lineno......" + lineno1 + " " +(int)linenum.get(i));
				//writer.write("lineno......" + lineno1 + " " +(int)linenum.get(i)+"\n");
				
				if(lineno1 == (int)linenum.get(i+1))
					break;
				if(lineno1 >= (int)linenum.get(i) && lineno1 < (int)linenum.get(i+1))
				{
					 writer.write(line1+"\n");
			
				}
				
			}writer.close();
			
			
		}
			/*if(intIndex == - 1 || intIndexname == -1) {
		        // System.out.println("name not found;");
				if(flag == 1 && namecount!=0)
				{
				
					filterline.add(linearr.get(lineno-1));
				}
				
				
		      } else {
		    	  System.out.println("history found at line: " +lineno);
		    	  filterline.add(linearr.get(lineno-3));
		    	  //System.out.println(linearr.get(lineno-3));
		    	  filterline.add(linearr.get(lineno-2));
		    	  //System.out.println(linearr.get(lineno-2));
		    	  filterline.add(linearr.get(lineno-1));
		    	  //System.out.println(linearr.get(lineno-1));
		    	  //if(intIndexname == -1)
		    	  flag =1;
		    	  namecount =0;
		    	 //break;
		         
		      }
			
		}
		for(String a: filterline){
			bw.write(a);
			bw.newLine();
			System.out.println(a);
			
		}
		bw.close();
		//num of shared resource:
		System.out.println("Number of Found unique name: " +  names.size());
		int k=0;
		for(String a: names){
			int tempcount =0;
			k++;
			System.out.println(a);
			while ((line = br1.readLine()) != null) {
				int intIndex = line.indexOf(a);
				//System.out.println(intIndex);
				if(intIndex == - 1) {
					//System.out.println("not shared resource");
				}
				else{
					tempcount++;
					arrofstr1 = line.split(" ");
					//System.out.println(arrofstr1[0]);
					for(String b: arrofstr){
						if(b.contains("item=0"))
						{
							// do nothing
						}
						else
							sharednames.add(a);
					}
				}
			}*/
		
			
			//System.out.println(k);
		BufferedWriter writer2 = new BufferedWriter(new FileWriter("/home/shaila/Documents/LocRoCon/mv_cat/test_multipletestcases/results/resourceonly6"));
			

		/*for(String a: sharednames){
			System.out.println(a);
			
		}*/
		
		/*for(String pid: process)
		{  
			writer1.write(pid+"\n");
		}*/
		
		for(String a: names){
		System.out.println("list" + a);
		writer2.write(a+"\n");
		}
	
		writer2.close();
		System.out.println("total num of resource:" + names.size());
		System.out.println("total num of process:" + process.size());
		System.out.println("total num of syscall:" + syscallcount);
		
		long endTime   = System.nanoTime();
		long totalTime = endTime - startTime;
		System.out.println("time:" +totalTime/1000000);
	}


}
