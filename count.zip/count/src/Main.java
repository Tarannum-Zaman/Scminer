import java.io.*;
import java.util.*;

public class Main {
	public static void main(String[] args){
		int i; int n= 58;
		int sum = 0;
		for(i = n; i>0; i--)
			sum = sum+i;
		
		System.out.println(sum);
		
	}

}
